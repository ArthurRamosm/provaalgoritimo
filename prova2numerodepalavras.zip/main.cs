/******************************************************************************

                            Online C# Compiler.
                Code, Compile, Run and Debug C# program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

using System;
class HelloWorld {
  static void Main() {
      Console.WriteLine("Digite uma frase:");
     string frase = Console.ReadLine();
      string [] palavra = frase.Split();
      int totalpalavras = palavra.Length;
      
      Console.WriteLine(totalpalavras);
  }
}