
    using System;
class HelloWorld {
  static void Main() {
      
      Console.WriteLine("Digite a primeira data nesse formato dd/mm/yyyy:");
      string Date1 = Console.ReadLine();
      
       Console.WriteLine("Digite a segundo data nesse formato dd/mm/yyyy:");
      string Date2 = Console.ReadLine();
      
      
      DateTime Date1A = DateTime.ParseExact(Date1, "dd/MM/yyyy", null);
      
      DateTime Date2A = DateTime.ParseExact(Date2, "dd/MM/yyyy", null);
      
      TimeSpan difference = Date2A - Date1A;
      
      int diasDiferenca = Math.Abs(difference.Days);
      
      Console.WriteLine("A Difenca de dias é:" + diasDiferenca);
  }
}