/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
 int dias, anos, meses, diasRestantes;

        Console.WriteLine("Digite o número de dias da idade:");
        dias = int.Parse(Console.ReadLine());

 
        int diasporano = 365;
        int diasPorMes = 30;

      
        anos = dias / dias;
        int restoAno = dias % diasporano;

  
        meses = restoAno / diasPorMes;
        diasRestantes = restoAno % diasPorMes;

        Console.WriteLine($"Anos: {anos}");
        Console.WriteLine($"Meses: {meses}");
        Console.WriteLine($"Dias: {diasRestantes}");
  }
}